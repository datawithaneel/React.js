import React, { useState } from "react";

export default function App() {
  const [task, setTask] = useState("");
  const [tasks, setTasks] = useState([]);

  const addTask = () => {
    if (!task.trim()) return;

    setTasks([
      ...tasks,
      { id: Date.now(), text: task.trim(), completed: false }
    ]);
    setTask("");
  };

  const toggleTask = (id) => {
    setTasks(
      tasks.map((item) =>
        item.id === id
          ? { ...item, completed: !item.completed }
          : item
      )
    );
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter((item) => item.id !== id));
  };

  const completed = tasks.filter((item) => item.completed).length;

  return (
    <main className="app">
      <section className="card">
        <div className="hero">
          <span className="badge">REACT.JS PROJECT</span>
          <h1>Task Manager</h1>
          <p>Plan your day. Complete your goals. 🚀</p>
        </div>

        <div className="input-row">
          <input
            value={task}
            onChange={(e) => setTask(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && addTask()}
            placeholder="What needs to be done?"
            aria-label="New task"
          />
          <button onClick={addTask}>Add Task</button>
        </div>

        <div className="stats">
          <span>Total: <strong>{tasks.length}</strong></span>
          <span>Completed: <strong>{completed}</strong></span>
        </div>

        <div className="task-list">
          {tasks.length === 0 ? (
            <div className="empty">
              <div className="empty-icon">📝</div>
              <h2>No tasks yet</h2>
              <p>Add your first task above.</p>
            </div>
          ) : (
            tasks.map((item) => (
              <div className={`task ${item.completed ? "done" : ""}`} key={item.id}>
                <button
                  className="check"
                  onClick={() => toggleTask(item.id)}
                  aria-label="Toggle task"
                >
                  {item.completed ? "✓" : ""}
                </button>

                <span onClick={() => toggleTask(item.id)}>{item.text}</span>

                <button
                  className="delete"
                  onClick={() => deleteTask(item.id)}
                  aria-label="Delete task"
                >
                  ×
                </button>
              </div>
            ))
          )}
        </div>

        <footer>
          Built with ⚛️ React.js
        </footer>
      </section>
    </main>
  );
}
