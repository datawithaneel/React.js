# ⚛️ React Task Manager

A small, clean and responsive Task Manager built with **React.js + Vite**.

## Features

- Add tasks
- Mark tasks as completed
- Delete tasks
- Enter key support
- Task counters
- Responsive mobile-friendly UI
- React Hooks (`useState`)
- Component-based React setup

## Run locally

```bash
npm install
npm run dev
```

Then open the local URL shown by Vite.

## Build for production

```bash
npm run build
```

## Technologies

- React.js
- JavaScript
- Vite
- CSS

## Author

Aneel
